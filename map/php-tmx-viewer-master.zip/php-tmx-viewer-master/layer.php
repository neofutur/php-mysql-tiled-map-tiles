<?php

class Layer {
//
};

?>