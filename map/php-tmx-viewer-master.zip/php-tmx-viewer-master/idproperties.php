<?php
if(PHP_VERSION_ID >= 50400) {
	require_once('idproperties_54.php');
}
else {
	require_once('idproperties_53.php');
}
?>