php-tmx-viewer
==============

a TMX map viewer written in PHP

DEPENDENCIES
============

It just needs the gd2 extension, possibly with freetype support if object names are shown.

It could be done with the gMagick or iMagick / MagickWand extension, but they aren't widespread enough (I did it in the previous version).

TODO
====

improve ui

add cache support

add other games in online list
