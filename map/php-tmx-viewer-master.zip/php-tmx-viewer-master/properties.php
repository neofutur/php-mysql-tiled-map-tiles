<?php
if(PHP_VERSION_ID >= 50400) {
	require_once('properties_54.php');
}
else {
	require_once('properties_53.php');
}
?>